# Dabbira V2 — Execution Brief

**Audience: the Claude Code agent assigned to run Dabbira's V2 design overhaul.**
Read this entire file first, plus `CLAUDE.md`, the skills in `.claude/skills/`, and
`design/inputs/pilot-feedback.md`. Then verify the environment and execute the phased
plan below, stopping at each gate for the human. All files referenced here are at the
repository root.

## 0. Your job, in one line

You orchestrate a **spec-driven** design overhaul: verify setup, then drive the workflow
by delegating to the **`design-lead`** subagent one phase at a time, pausing at each gate
for human review. Neither you nor the design-lead writes production code — design work
produces specs in `/design` that a **separate coding agent** implements.

## 1. The project (so you understand what you're working on)

**Dabbira** is an Arabic-first PWA for Lebanon that connects **property owners** with
**service providers** for property services, plus a **materials marketplace** whose
products can be referenced inside provider offers. Money is **off-platform**: cash +
lead-generation + ratings + verification — no in-app payments. The app's value is
matchmaking, trust signals, and clear communication.

**Stack:** Next.js 16 (App Router, RSC + Server Actions, TS strict) · Tailwind v4
(CSS-first `@theme` + CSS variables, no `tailwind.config.js`) · shadcn/ui `base-nova`
on **Base UI** (`@base-ui/react`, not Radix) · `cn()`/CVA · lucide-react, sonner,
next-themes · i18n locales `ar`/`fr`/`en`, `dir` from locale · RTL today is a brittle
manual `[dir="rtl"]` flip layer over physical utilities (tech debt to migrate to logical
properties). Full detail in `CLAUDE.md`.

**Status:** live pilot with a small panel (≈15 owners, 3–5 providers, all known to the
founder). Feedback says the flows are confusing and the Arabic feels off.

## 2. Why V2 — the problem (read `design/inputs/pilot-feedback.md` for verbatim)

The pilot feedback is **not** about visual polish. It is information architecture, input
method, content, typography, and an offer model that fights the local trust norm:

- Onboarding is too heavy ("too many buttons and I'm still not in").
- The request wizard gives no guidance, progress, or completion/next-step clarity
  ("I think I'm done but I'm not"; users abandon).
- Category selection is both overwhelming and under-specified; single-select where
  multiple needs are required.
- Users want to **describe problems by voice note / photo / video**, not type.
- Providers won't quote blind — the local norm is **inspect, then quote**.
- Arabic is **subtly off**: too small, disliked font, weak hierarchy, and unnatural
  (MSA-feeling) wording — i.e. typography + language, not broken layout.

## 3. The V2 thesis (hypotheses to validate, not settled design)

1. Rich-media request input (voice/photo/video; keep the form short).
2. Inspect-then-quote as a first-class offer path (fits cash + ratings).
3. Register late; reach value in ~2 clicks; phone-OTP.
4. Arabic as type + language: larger per-script type scale, warmer/legible face, clear
   hierarchy, plain Levantine-leaning copy authored Arabic-first.
5. Guided triage replacing the flat list: narrow, multi-select, category-specific
   follow-ups, visible progress, and a clear "what happens next."

Validate each with the founder's panel before treating it as final.

## 4. How we work (operating model)

- **Two agents, file-based handoff.** The `design-lead` subagent does research, IA,
  RTL/Arabic, design system, content, and flows, writing **only** to `/design`. The
  coding agent builds from `/design`. `design/INDEX.md` is the source of truth.
- **You delegate explicitly.** Auto-routing to subagents is unreliable, so invoke
  `design-lead` by name for each design task; don't do design work in the main thread.
- **Phase gates.** One phase per turn; stop and report; wait for the human to release you
  to the next phase. The human reviews each phase's output as Git diffs.
- **Skills `design-lead` uses:** `ux-audit`, `rtl-arabic-design`, `arabic-first-content`,
  `design-system-tokens`, `flow-spec`, `usability-test-protocol`, and `design-handoff`
  (the contract + Definition of Done).

## 5. Human pre-flight — NOT delegable (confirm before you start)

These require a person; you cannot do them. If any is missing or unclear, **ask the human
and wait**:

- CLI + VS Code extension installed and signed in.
- This repo opened as the workspace folder; the kit placed at the **repo root**
  (`CLAUDE.md`, `.claude/`, `design/`, `.mcp.json`, this file).
- The **playwright** MCP approved in the session.
- The **live pilot URL**, and a way into any **behind-login** flows (the human logs into
  the Playwright browser or provides a test account — never your real credentials).
- The two scope decisions confirmed (see §7). Figma MCP is optional and only needed later.

## 6. Setup verification — do this first, then report

Run these checks (filesystem + capability) and give the human a short readiness summary:

1. Confirm the kit is at root: `CLAUDE.md`, `.claude/agents/design-lead.md`, the seven
   `.claude/skills/*/SKILL.md`, `design/inputs/pilot-feedback.md`, `.mcp.json`.
2. Read `CLAUDE.md` and `design/inputs/pilot-feedback.md` fully.
3. Confirm the **playwright** MCP tools are available to you (try a benign navigation to
   the pilot URL). If they aren't, ask the human to approve the MCP.
4. Confirm you can write under `/design` (create `design/INDEX.md` if absent, using the
   status table format from the `design-handoff` skill).

Report: what's present, what's missing, and whether you're clear to start Phase 1.

## 7. Confirm two assumptions (ask the human at the start of Phase 1)

The kit assumes, until told otherwise:

- **Scope:** V2 is a focused redesign of the core loop (onboarding → request → offer →
  site-visit → completion → rating), worst-first and incremental, no fixed deadline.
- **Coding agent:** it can build **both** UI and backend, so specs may include backend
  features (media upload/storage, transcription, a site-visit state, a multi-select
  request model) — but tag each spec UI-only vs backend, and sequence UI-only wins first
  so they ship regardless of backend timing.

If the human corrects either, adjust the plan accordingly.

## 8. Execution plan (one phase per turn — delegate each to `design-lead`, then STOP)

**Phase 1 — Discover (audit).** Tell `design-lead`: open the live pilot via Playwright,
Arabic first then fr/en, phone viewport; reproduce onboarding, post-a-request,
submit-offer, and specify-materials-in-offer (map the last one as-is); run `ux-audit` plus
the Arabic pass from `rtl-arabic-design`; write `design/audit/audit.md` (findings table,
as-is Mermaid maps, worst-first shortlist, each issue tagged UI-only/backend). → STOP and
summarize the top issues.

**Phase 2 — Research.** `design-lead` writes a moderated-test protocol
(`usability-test-protocol`) for the panel; **the human runs the sessions** (Arabic for
Arabic users); `design-lead` synthesizes findings. → STOP and summarize.

**Phase 3 — Define.** `design-lead` produces the IA, `design/system/tokens.json` (incl.
the Arabic per-script type scale), the RTL/Arabic spec, and the trilingual copy deck
(`arabic-first-content`, Arabic canonical, flagging strings pending a native reviewer). →
STOP.

**Phase 4 — Design.** `design-lead` writes flow specs + self-contained HTML/Tailwind
prototypes for the priority flows, worst-first (`flow-spec`). → STOP.

**Phase 5 — Validate.** `design-lead` prepares a prototype walkthrough; **the human
tests** with a few panel users before any code is written. → STOP.

**Phase 6 — Handoff.** `design-lead` finalizes specs and marks them `ready` in
`design/INDEX.md`, with acceptance criteria and the three required checks (RTL pass,
real-Arabic-content pass, Arabic-typography check). The **coding agent** implements; you
do not write production code. → Report what's ready to build.

After each phase, wait for the human's "proceed" before continuing.

## 9. Guardrails (non-negotiable)

- `design-lead` writes only inside `/design`; never `src/` or config. You do not write
  production code — that is the separate coding agent's job.
- Arabic is canonical: design/write Arabic first, derive en/fr; a native Lebanese reviewer
  validates copy tone before it's final.
- Western (0-9) numerals in the Arabic UI.
- Decisions are evidence-based (audit + panel), not aesthetic preference; label judgment
  calls as hypotheses.
- Flag backend dependencies; sequence UI-only wins first.
- Never enter credentials, approve MCPs, or accept terms on the human's behalf. When
  blocked (a login, a product decision, a missing tool), ask the human and wait.

---

**Human — to delegate this:** place this file and the kit at the repo root, complete the
§5 pre-flight, then send the agent:

> Read EXECUTION-BRIEF.md and CLAUDE.md, run the setup verification in §6, confirm the §7
> assumptions with me, then begin Phase 1 and stop at the gate.
