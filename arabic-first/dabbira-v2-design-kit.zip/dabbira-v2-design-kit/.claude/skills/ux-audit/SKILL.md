---
name: ux-audit
description: >
  How to run a structured UX audit of the live Dabbira pilot. USE THIS at the start
  of V2, or whenever asked to review, diagnose, or "find the problems with" a screen
  or flow. Covers reproducing flows in the live app, heuristic evaluation with a
  severity scale, an Arabic-specific legibility + naturalness pass, mapping findings
  to the flagged pilot feedback, and the audit output format. Always load the live
  app via the browser MCP before auditing — do not audit from memory or screenshots
  alone.
---

# UX Audit — Dabbira

## Method

1. **See the real app.** Use the browser MCP to open the pilot, switch locale to
   **Arabic first** (then en/fr), and reproduce each flow end to end on a phone-sized
   viewport. Screenshot the key states.
2. **Map the as-is journey** for each flow, including the **materials-in-offer flow**
   (not yet documented — capture exactly how it works today).
3. **Heuristic evaluation** against Nielsen's 10 heuristics, with attention to the
   patterns the pilot surfaced: visibility of system status ("I think I'm done but
   I'm not / what happens next"), match to the real world (terminology), user
   control, error prevention, recognition over recall, flexibility, and minimalist
   design (option overload).
4. **Arabic pass** (use the `rtl-arabic-design` skill): legibility (size, weight,
   line-height), wording naturalness, hierarchy, mixed-content rendering, and
   numerals.
5. **Tie each finding to evidence** — which pilot quote, or which observed behavior,
   it explains.

## Severity scale

- **4 – Blocker:** stops the core task (e.g. "I gave up submitting the request").
- **3 – Serious:** major friction / likely abandonment.
- **2 – Moderate:** noticeable, fixable annoyance.
- **1 – Minor / polish.**
- **0 – Note / opportunity.**

## Output

Write `design/audit/audit.md` with:

- A short summary of what was tested and on what device/locale.
- A findings table: `ID · Flow · Heuristic · Finding · Evidence · Severity ·
  UI-only or Backend · Proposed direction`.
- An as-is flow map (Mermaid) per flagged flow.
- A ranked shortlist of the top issues to fix first (worst flows first).

Keep proposals at the level of *direction*, not final design — detailed flows come
later via `flow-spec`. Mark every proposal as UI-only or backend-dependent.
