---
name: flow-spec
description: >
  How to specify a user flow or multi-step wizard for Dabbira (onboarding,
  post-a-request, submit-offer, site-visit, specify-materials-in-offer, etc.). USE
  THIS whenever designing or redesigning any task flow or wizard, or when feedback is
  about confusion, "too many steps," "I don't know what to fill," or "what happens
  next." Produces a flow spec with diagram, step-by-step states, progress and
  completion handling, acceptance criteria, and optionally an HTML/Tailwind prototype.
---

# Flow / Wizard Spec — Dabbira

The pilot's biggest losses are in the flows ("I gave up submitting the request").
Specify each so it guides, sets expectations, and never leaves the user unsure.

## Priority order (worst-first)

1. Onboarding / register-late (reach value in ~2 clicks; OTP; defer account).
2. Post-a-request (rich-media input + guided triage + multi-select + dynamic
   follow-ups + progress + "what happens next").
3. Submit-offer incl. **inspect-then-quote** (propose visit → firm offer after).
4. Specify-materials-in-offer (map as-is first, then redesign).
5. Status tracking (request posted → offers → visit → agreed → done → rate).

## What each flow spec contains (`design/flows/<flow>.md`)

- **Goal & entry points** — who, from where, what success looks like.
- **Flow diagram** (Mermaid) — steps, decisions, branches, exits.
- **Step-by-step** — for each step: purpose, fields (required vs optional, with
  defaults and examples), inputs (incl. voice/photo/video where relevant),
  validation, and the empty/loading/error states.
- **Progress + completion** — a visible step indicator; an explicit "you're done +
  here's what happens next" screen; status afterward.
- **Guidance** — inline, minimal; never a wall of text.
- **Arabic-first** — author labels/CTAs via `arabic-first-content`; apply
  `rtl-arabic-design` to layout and type.
- **Dependencies** — mark each capability UI-only or **backend** (media upload,
  transcription, multi-select data model, site-visit state) and note sequencing.
- **Acceptance criteria** — testable statements per screen (see `design-handoff`),
  including the RTL, real-Arabic, and Arabic-typography checks.

## Prototypes (`design/prototypes/<flow>.html`)

When a visual contract helps, produce a self-contained **HTML + Tailwind v4**
prototype using the design tokens and mirroring the component classes. This is a
design artifact, not production code — it must live under `/design`, never in `src/`.
It gives the coding agent a near-1:1 target and gives the panel something to test.
