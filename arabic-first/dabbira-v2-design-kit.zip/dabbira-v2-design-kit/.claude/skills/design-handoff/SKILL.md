---
name: design-handoff
description: >
  The contract for handing design work to the coding agent. USE THIS whenever
  packaging, organizing, or finalizing any spec for implementation, writing
  acceptance criteria, or updating the spec index. Defines the /design folder
  structure, the spec package format, the Definition of Done (including mandatory RTL,
  real-Arabic, and Arabic-typography checks), and the rule that the Design Lead writes
  only to /design while the coding agent builds only from it.
---

# Design → Code Handoff — Dabbira

Handoff is **file-based**. The Design Lead writes specs to `/design`; the coding agent
builds from them. `/design/INDEX.md` is the single source of truth for what exists and
its status.

## `/design` structure

```
design/
├── INDEX.md                  # spec index + status (source of truth)
├── audit/audit.md            # current-state UX audit
├── research/                 # protocols + findings
├── ia/                       # sitemap, navigation model
├── system/                   # tokens.json + components/*.md
├── content/copy-deck.md      # trilingual copy (AR canonical)
├── flows/<flow>.md           # flow specs
└── prototypes/<flow>.html    # HTML/Tailwind visual contracts (design artifacts)
```

## INDEX.md

A table: `Spec · Path · Phase · Status (draft / in-review / ready / built) ·
Depends on (UI-only or backend) · Notes`. Update it whenever a spec changes state.
The coding agent picks up only specs marked **ready**.

## Spec package (what "ready" means)

Each flow/screen spec ready for build includes:

- The flow diagram and step-by-step states.
- A link to its HTML prototype (if any) and the tokens/components it uses.
- Final, native-reviewed copy strings (or a clear list of any still pending).
- **Acceptance criteria** — numbered, testable, e.g.:
  - "Owner can start a request and attach a voice note before creating an account."
  - "Wizard shows current step / total at all times; the final screen states what
    happens next."
  - "A request can contain multiple service needs."
- **Required checks** on every screen:
  - **RTL pass** — mirrored layout; logical properties; directional icons flip.
  - **Real-Arabic-content pass** — built and reviewed with real Arabic (no Lorem
    Ipsum); layout holds at ±25% string length and at mobile widths.
  - **Arabic-typography check** — per-script size, line-height ≥1.5, medium weight,
    no letter-spacing.
- **Dependencies** — what is UI-only vs backend, and the suggested build order.

## Rules

- Design Lead writes **only** inside `/design`. Never `src/`.
- Coding agent builds **only** from `ready` specs and the acceptance criteria; if a
  spec is ambiguous, it asks the Design Lead to resolve it in the spec rather than
  guessing.
- A spec is "built" only when its acceptance criteria and all three required checks
  pass.
