---
name: arabic-first-content
description: >
  How to write Dabbira's UI copy. USE THIS for any microcopy, labels, headers, CTAs,
  empty/error/success messages, onboarding text, or terminology — and whenever the
  feedback is "the words are weird / not clear / hard to understand." Copy is authored
  in Arabic as the canonical source and then derived into English and French; it must
  read as natural, warm, plain Lebanese-leaning Arabic, not formal MSA or literal
  translations. Produces a trilingual copy deck and requires a native-reviewer step.
---

# Arabic-First Content — Dabbira

Pilot users (both sides) said the wording is "weird," "not clear," "not easy to
understand." That is the signature of UI copy translated from English into formal
MSA. Fix it by changing the authoring order.

## Principles

1. **Author Arabic first**, then derive en/fr. Do not write English and translate.
2. **Register:** plain, warm, conversational-but-professional — the voice of a
   helpful local dispatcher or neighbor, not a government form. Avoid stiff MSA and
   word-for-word renderings of English UI verbs.
3. **Concrete and familiar.** Use the words people actually use for home repairs and
   services in Lebanon. CTAs should sound like speech.
4. **Short.** Labels and buttons are tight; guidance is one helpful line, not a
   paragraph (users said "I have to read so much").
5. **Set expectations in words.** Every step says what's needed and what happens
   next; completion screens confirm and tell the user what comes after.
6. **Test terminology, don't assume.** What do owners and providers call: a service
   request, an offer, a site visit, a service provider, "submit"? Validate the actual
   nouns/verbs with the panel.

## Examples (illustrative — confirm by testing, do not ship blind)

- A formal "إرسال الطلب" CTA likely reads better as something closer to spoken
  "ابعت طلبك". Test both with users.
- "مزوّد خدمة" (service provider) may feel bureaucratic; check what users actually say
  (e.g. the trade itself — "كهربائي/سبّاك" — or a friendlier umbrella term).

These are hypotheses for the panel, not final copy.

## Output

Write `design/content/copy-deck.md` as a table keyed by string ID:
`ID · Context/Screen · AR (canonical) · EN · FR · Notes`.

Then require a **native Lebanese Arabic reviewer** to pass over the AR column for
tone and naturalness before any copy is handed off. Note in the deck which strings
are still pending review.
