---
name: design-system-tokens
description: >
  How to define Dabbira's design system as tokens and component specs. USE THIS when
  setting up or revising colors, typography (including the Arabic per-script scale),
  spacing, radii, elevation, motion, or any reusable component's appearance and states.
  Outputs tokens that map cleanly onto the project's Tailwind v4 `@theme` + CSS
  variables and shadcn `base-nova` on Base UI. Component specs must cover every state
  and explicit RTL behavior.
---

# Design System & Tokens — Dabbira

Produce a single source of truth that the coding agent can wire into Tailwind v4's
CSS-first `@theme` and the existing CSS variables.

## Tokens (`design/system/tokens.json`)

- **Color:** brand, surfaces, text, semantic (success/warn/error/info), with
  light + dark values. Meet WCAG contrast (4.5:1 body, 3:1 large text).
- **Typography — per script** (critical): a **Latin** scale and a larger **Arabic**
  scale (see `rtl-arabic-design`): Arabic base ≈1.1–1.2× Latin, line-height
  ≥1.5 (~1.6–1.8), medium body weight, **no letter-spacing on Arabic**. Define
  display / h1 / h2 / h3 / body / small for each script, plus the chosen font
  families (Arabic face TBD by testing).
- **Spacing / radii / elevation / motion:** a modular spacing scale, radius tokens
  matching `base-nova`, shadow tokens, and a small motion set (durations + easings;
  directional animations mirror in RTL).

Express layout-related tokens in **logical** terms so direction is automatic.

## Component specs (`design/system/components/<name>.md`)

For each component (start with the ones in `src/components/ui/`):

- Anatomy + variants (via CVA), and the tokens it consumes.
- **All states:** default, hover, focus-visible, active, disabled, loading, empty,
  error, success.
- **RTL behavior:** what mirrors, what doesn't, icon direction.
- **Base UI note:** target Base UI's (`@base-ui/react`) actual API and verify its
  direction/RTL support — do not assume Radix patterns.
- Accessibility: roles, keyboard, focus order, touch target ≥44px.

Keep it implementation-ready but framework-honest: describe behavior and tokens; the
coding agent writes the React.
