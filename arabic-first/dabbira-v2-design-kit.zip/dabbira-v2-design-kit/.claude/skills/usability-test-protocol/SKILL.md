---
name: usability-test-protocol
description: >
  How to design and synthesize lightweight moderated usability tests with Dabbira's
  pilot panel (the ~15 owners and 3–5 providers the founder knows). USE THIS when
  validating a flow or prototype, planning research, or turning user sessions into
  prioritized findings. The founder runs the sessions; this skill produces the
  protocol and the synthesis. Reach for it before treating any V2 hypothesis as
  settled.
---

# Usability Test Protocol — Dabbira

You have a rare asset: ~15 owners and 3–5 providers the founder knows personally.
That is enough to catch most issues with short, moderated walkthroughs. Use them.

## Protocol (`design/research/protocol-<round>.md`)

- **Goal & hypotheses** — what this round tests (e.g. "does register-late + guided
  triage let an owner post a request without help?").
- **Participants** — mix owners and providers; run **Arabic-language sessions** for
  Arabic-dominant users (especially providers).
- **Tasks** — realistic, outcome-framed, not instructions. e.g. "You have a leaking
  pipe — get help through the app." Never narrate the steps.
- **Method** — think-aloud; moderator stays quiet and non-leading; capture where they
  hesitate, backtrack, or give up, plus verbatim quotes.
- **Pre/post questions** — what they expected; what they'd call things (terminology);
  trust ("would you act on this offer? why/not?"); the inspect-then-quote question for
  providers.
- **Logistics** — in-person or screen-share; record with consent; 20–30 min each.

## Synthesis (`design/research/findings-<round>.md`)

- Per task: completion (unaided / aided / failed), time/clicks if useful, and the
  friction points with supporting quotes.
- Cross-cut themes ranked by severity (reuse the `ux-audit` scale).
- Terminology findings → feed `arabic-first-content`.
- Clear "what to change" list, separating UI-only from backend-dependent.

Five to eight participants per round is plenty; test, fix, retest rather than one big
study.
