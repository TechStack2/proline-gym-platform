# /design — Dabbira V2 design source of truth

Everything the Design Lead agent produces lives here. The coding agent builds from
here. See the `design-handoff` skill for the full contract.

- `INDEX.md` — the spec index + status. **Start here.** Created during the Define phase.
- `audit/` — current-state UX audit (Discover phase).
- `research/` — usability protocols and findings (Research phase).
- `ia/` — sitemap and navigation model (Define phase).
- `system/` — `tokens.json` and per-component specs (Define phase).
- `content/` — `copy-deck.md`, trilingual with Arabic as the canonical column.
- `flows/` — flow/wizard specs (Design phase).
- `prototypes/` — self-contained HTML/Tailwind visual contracts (design artifacts,
  not production code).

Status legend used in `INDEX.md`: `draft → in-review → ready → built`. The coding
agent implements only specs marked `ready`.
