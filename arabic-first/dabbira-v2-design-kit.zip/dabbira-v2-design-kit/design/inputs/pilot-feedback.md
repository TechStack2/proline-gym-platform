# Pilot Feedback & Discovery Inputs (raw)

Raw evidence from the Dabbira pilot. The *synthesized* direction (the V2 thesis,
trust model, principles) lives in `CLAUDE.md`. This file is the unfiltered input the
audit and research should trace findings back to.

## Calibration

- The Arabic is **subtly off**, not visibly broken. The layout isn't obviously
  bugged — the Arabic problems are **typography** (size, font, hierarchy) and
  **wording** (unnatural terms), not gross mirroring failures.

## Property owner feedback (verbatim)

- The registration is confusing. I clicked too many buttons and still I'm not in. In
  other apps, I get to the service in 2 clicks.
- When I fill the service request I think I'm done but I'm not. What's all the info I
  need to fill? What happens next? I don't know. The app has no guidance.
- I need to read so much to figure things out.
- I literally gave up on submitting the request — it's too confusing.
- I don't know what type of service I need; there are too many options.
- The service I need is multiple items from the list and I can only select one.
- I would rather speak my need like a WhatsApp recording instead of typing
  everything. Why can't I just video the problem I need solved? Wouldn't that be
  easier?
- I need more details from a list so I can better specify my need.
- The Arabic letters are too small and the headers are confusing.
- The terms used are weird and don't make sense easily.

## Service provider feedback (verbatim)

- How can I provide an offer based on this little info? I would rather visit and see.
- Most people want an offer after you've inspected; they don't trust an offer without
  a pre-inspection.
- The Arabic language is not easy to understand and the words are not clear.
- The words are too small and I can't easily decipher the words and meaning. The
  Arabic is too small.
- I don't like the font, it's not fun.
- The quality of the request is important for me to give an accurate offer.

## Pilot panel (who to test with)

- < 15 property owners and 3–5 service providers, **all personally known to the
  founder** — use them for moderated walkthroughs.
- **Providers:** mostly Arabic, some English.
- **Owners:** ~60% Arabic, ~20% agnostic (more comfortable in English/French),
  ~20% English/French.

## Trust & money model

- **Cash + lead-gen + ratings + verification.** No in-app payments or escrow. The app
  matches, signals trust, and supports communication; money happens off-platform.
